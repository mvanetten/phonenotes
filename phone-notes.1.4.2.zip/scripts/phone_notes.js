jQuery(document).ready(function() {	
	jQuery('#pn_date').intimidatetime({
	});
});